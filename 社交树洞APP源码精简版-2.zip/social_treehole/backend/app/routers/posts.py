from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from sqlalchemy import desc, func
from typing import List

from ..database import get_db
from ..models.models import Post, Like, Comment, User
from ..schemas.schemas import PostCreate, PostResponse, CommentCreate, CommentResponse, CommentInfo
from ..auth import get_current_user

router = APIRouter(prefix="/api/posts", tags=["树洞帖子"])


def get_post_response(post: Post, current_user: User = None, db: Session = None):
    """构建帖子响应数据"""
    author_nickname = "匿名用户" if post.is_anonymous else post.author.nickname
    
    # 获取评论
    comments = []
    for comment in post.comments[:20]:  # 最多返回20条评论
        comment_author = "匿名用户" if comment.is_anonymous else comment.author.nickname
        comments.append(CommentInfo(
            id=comment.id,
            content=comment.content,
            created_at=comment.created_at,
            author_nickname=comment_author
        ))
    
    # 检查当前用户是否点赞
    is_liked = False
    if current_user and db:
        like = db.query(Like).filter(
            Like.post_id == post.id,
            Like.user_id == current_user.id
        ).first()
        is_liked = like is not None
    
    return PostResponse(
        id=post.id,
        content=post.content,
        mood=post.mood,
        is_anonymous=post.is_anonymous,
        like_count=post.like_count,
        comment_count=post.comment_count,
        created_at=post.created_at,
        author_nickname=author_nickname,
        is_liked=is_liked,
        comments=comments
    )


@router.get("/", response_model=List[PostResponse])
def get_posts(
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    page: int = Query(None, ge=1),
    page_size: int = Query(None, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取树洞帖子列表（按时间倒序），兼容page/page_size参数"""
    if page is not None and page_size is not None:
        skip = (page - 1) * page_size
        limit = page_size
    posts = db.query(Post).order_by(desc(Post.created_at)).offset(skip).limit(limit).all()
    return [get_post_response(post, current_user, db) for post in posts]


@router.get("/my", response_model=List[PostResponse])
def get_my_posts(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=200),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取当前用户发布的帖子"""
    posts = db.query(Post).filter(
        Post.author_id == current_user.id
    ).order_by(desc(Post.created_at)).offset(skip).limit(limit).all()
    return [get_post_response(post, current_user, db) for post in posts]


@router.post("/", response_model=PostResponse)
def create_post(
    post_create: PostCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """发布新树洞"""
    if not post_create.content.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="内容不能为空"
        )
    
    db_post = Post(
        content=post_create.content,
        mood=post_create.mood,
        is_anonymous=post_create.is_anonymous,
        author_id=current_user.id
    )
    db.add(db_post)
    db.commit()
    db.refresh(db_post)
    return get_post_response(db_post, current_user, db)


@router.get("/{post_id}", response_model=PostResponse)
def get_post(
    post_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取单个帖子详情"""
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="帖子不存在"
        )
    return get_post_response(post, current_user, db)


@router.post("/{post_id}/like", response_model=PostResponse)
def toggle_like(
    post_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """点赞/取消点赞"""
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="帖子不存在"
        )
    
    existing_like = db.query(Like).filter(
        Like.post_id == post_id,
        Like.user_id == current_user.id
    ).first()
    
    if existing_like:
        # 取消点赞
        db.delete(existing_like)
        post.like_count = max(0, post.like_count - 1)
    else:
        # 添加点赞
        like = Like(post_id=post_id, user_id=current_user.id)
        db.add(like)
        post.like_count += 1
    
    db.commit()
    db.refresh(post)
    return get_post_response(post, current_user, db)


@router.post("/{post_id}/comments", response_model=CommentResponse)
def create_comment(
    post_id: int,
    comment_create: CommentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """发表评论"""
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="帖子不存在"
        )
    
    if not comment_create.content.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="评论内容不能为空"
        )
    
    comment = Comment(
        content=comment_create.content,
        is_anonymous=comment_create.is_anonymous,
        post_id=post_id,
        author_id=current_user.id
    )
    db.add(comment)
    post.comment_count += 1
    db.commit()
    db.refresh(comment)
    
    author_nickname = "匿名用户" if comment.is_anonymous else current_user.nickname
    return CommentResponse(
        id=comment.id,
        content=comment.content,
        created_at=comment.created_at,
        post_id=post_id,
        author_nickname=author_nickname
    )


@router.get("/{post_id}/comments", response_model=List[CommentResponse])
def get_comments(
    post_id: int,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取帖子的评论列表"""
    post = db.query(Post).filter(Post.id == post_id).first()
    if not post:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="帖子不存在"
        )
    
    comments = db.query(Comment).filter(
        Comment.post_id == post_id
    ).order_by(desc(Comment.created_at)).offset(skip).limit(limit).all()
    
    result = []
    for comment in comments:
        author_nickname = "匿名用户" if comment.is_anonymous else comment.author.nickname
        result.append(CommentResponse(
            id=comment.id,
            content=comment.content,
            created_at=comment.created_at,
            post_id=post_id,
            author_nickname=author_nickname
        ))
    return result


@router.delete("/{post_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_post(
    post_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """删除自己的帖子"""
    post = db.query(Post).filter(Post.id == post_id, Post.author_id == current_user.id).first()
    if not post:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="帖子不存在或无权限删除"
        )
    
    db.delete(post)
    db.commit()
