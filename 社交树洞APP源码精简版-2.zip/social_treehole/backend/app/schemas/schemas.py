from pydantic import BaseModel
from datetime import datetime
from typing import Optional, List


class UserBase(BaseModel):
    username: str
    nickname: Optional[str] = None


class UserCreate(UserBase):
    password: str


class UserLogin(BaseModel):
    username: str
    password: str


class UserResponse(UserBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str
    user: UserResponse


class PostBase(BaseModel):
    content: str
    mood: Optional[str] = "平静"
    is_anonymous: Optional[bool] = True


class PostCreate(PostBase):
    pass


class CommentInfo(BaseModel):
    id: int
    content: str
    created_at: datetime
    author_nickname: str

    class Config:
        from_attributes = True


class PostResponse(PostBase):
    id: int
    like_count: int
    comment_count: int
    created_at: datetime
    author_nickname: str
    is_liked: Optional[bool] = False
    comments: List[CommentInfo] = []

    class Config:
        from_attributes = True


class CommentCreate(BaseModel):
    content: str
    is_anonymous: Optional[bool] = True


class CommentResponse(BaseModel):
    id: int
    content: str
    created_at: datetime
    post_id: int
    author_nickname: str

    class Config:
        from_attributes = True
