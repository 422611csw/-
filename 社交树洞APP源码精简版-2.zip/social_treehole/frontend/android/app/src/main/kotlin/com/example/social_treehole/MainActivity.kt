package com.example.social_treehole

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
