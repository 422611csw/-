class Post {
  final int id;
  final String content;
  final String mood;
  final bool isAnonymous;
  int likeCount;
  int commentCount;
  final DateTime createdAt;
  final String authorNickname;
  bool isLiked;
  final List<Comment> comments;

  Post({
    required this.id,
    required this.content,
    this.mood = 'default',
    this.isAnonymous = true,
    this.likeCount = 0,
    this.commentCount = 0,
    required this.createdAt,
    this.authorNickname = '匿名用户',
    this.isLiked = false,
    this.comments = const [],
  });

  factory Post.fromJson(Map<String, dynamic> json) {
    return Post(
      id: json['id'],
      content: json['content'],
      mood: json['mood'] ?? 'default',
      isAnonymous: json['is_anonymous'] ?? true,
      likeCount: json['like_count'] ?? 0,
      commentCount: json['comment_count'] ?? 0,
      createdAt: DateTime.parse(json['created_at']),
      authorNickname: json['author_nickname'] ?? '匿名用户',
      isLiked: json['is_liked'] ?? false,
      comments: (json['comments'] as List<dynamic>? ?? [])
          .map((c) => Comment.fromJson(c))
          .toList(),
    );
  }
}

class Comment {
  final int id;
  final String content;
  final DateTime createdAt;
  final String authorNickname;

  Comment({
    required this.id,
    required this.content,
    required this.createdAt,
    this.authorNickname = '匿名用户',
  });

  factory Comment.fromJson(Map<String, dynamic> json) {
    return Comment(
      id: json['id'],
      content: json['content'],
      createdAt: DateTime.parse(json['created_at']),
      authorNickname: json['author_nickname'] ?? '匿名用户',
    );
  }
}

class User {
  final int id;
  final String username;
  final String nickname;
  final DateTime createdAt;

  User({
    required this.id,
    required this.username,
    required this.nickname,
    required this.createdAt,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'],
      username: json['username'],
      nickname: json['nickname'] ?? '匿名用户',
      createdAt: DateTime.parse(json['created_at']),
    );
  }
}
