import 'package:flutter/material.dart';
import '../services/api_service.dart';

class CreatePostPage extends StatefulWidget {
  const CreatePostPage({super.key});

  @override
  State<CreatePostPage> createState() => _CreatePostPageState();
}

class _CreatePostPageState extends State<CreatePostPage> {
  final _contentController = TextEditingController();
  bool _isAnonymous = true;
  String _selectedMood = 'default';
  bool _isSubmitting = false;

  final List<Map<String, String>> _moods = [
    {'value': 'default', 'emoji': '🌳', 'label': '普通'},
    {'value': 'happy', 'emoji': '😊', 'label': '开心'},
    {'value': 'sad', 'emoji': '😢', 'label': '难过'},
    {'value': 'angry', 'emoji': '😠', 'label': '生气'},
    {'value': 'love', 'emoji': '❤️', 'label': '喜欢'},
    {'value': 'confused', 'emoji': '😕', 'label': '困惑'},
    {'value': 'excited', 'emoji': '🤩', 'label': '兴奋'},
  ];

  Future<void> _submitPost() async {
    if (_contentController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请输入内容')),
      );
      return;
    }

    setState(() => _isSubmitting = true);
    try {
      await ApiService().createPost(
        _contentController.text.trim(),
        mood: _selectedMood,
        isAnonymous: _isAnonymous,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('发布成功')),
      );
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString().replaceAll('Exception: ', ''))),
      );
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  void dispose() {
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('发布树洞'),
        backgroundColor: Colors.teal.shade700,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          TextButton(
            onPressed: _isSubmitting ? null : _submitPost,
            child: _isSubmitting
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                  )
                : const Text('发布', style: TextStyle(color: Colors.white, fontSize: 16)),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 心情选择
            const Text('选择心情', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
            const SizedBox(height: 12),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: _moods.map((mood) {
                final isSelected = _selectedMood == mood['value'];
                return GestureDetector(
                  onTap: () => setState(() => _selectedMood = mood['value']!),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: isSelected ? Colors.teal.shade100 : Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: isSelected ? Colors.teal.shade700 : Colors.transparent,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(mood['emoji']!, style: const TextStyle(fontSize: 18)),
                        const SizedBox(width: 4),
                        Text(mood['label']!),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 24),
            // 内容输入
            TextField(
              controller: _contentController,
              maxLines: 10,
              maxLength: 500,
              decoration: const InputDecoration(
                hintText: '把你的心事写在这里，没有人知道你是谁...',
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
            const SizedBox(height: 16),
            // 匿名开关
            SwitchListTile(
              title: const Text('匿名发布'),
              subtitle: const Text('开启后其他用户看不到你的昵称'),
              value: _isAnonymous,
              onChanged: (value) => setState(() => _isAnonymous = value),
              activeColor: Colors.teal.shade700,
              contentPadding: EdgeInsets.zero,
            ),
          ],
        ),
      ),
    );
  }
}
