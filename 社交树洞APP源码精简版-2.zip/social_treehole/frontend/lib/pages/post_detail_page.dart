import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/post.dart';
import '../services/api_service.dart';

class PostDetailPage extends StatefulWidget {
  final Post post;

  const PostDetailPage({super.key, required this.post});

  @override
  State<PostDetailPage> createState() => _PostDetailPageState();
}

class _PostDetailPageState extends State<PostDetailPage> {
  final _commentController = TextEditingController();
  bool _isAnonymous = true;
  bool _isSubmitting = false;
  List<Comment> _comments = [];
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _comments = List.from(widget.post.comments);
    _loadComments();
  }

  @override
  void dispose() {
    _commentController.dispose();
    super.dispose();
  }

  String _formatTime(DateTime time) {
    return DateFormat('MM-dd HH:mm').format(time);
  }

  Future<void> _loadComments() async {
    setState(() => _isLoading = true);
    try {
      final comments = await ApiService().getComments(widget.post.id);
      setState(() => _comments = comments);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceAll('Exception: ', ''))),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _submitComment() async {
    if (_commentController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请输入评论内容')),
      );
      return;
    }

    setState(() => _isSubmitting = true);
    try {
      final comment = await ApiService().createComment(
        widget.post.id,
        _commentController.text.trim(),
        isAnonymous: _isAnonymous,
      );
      setState(() {
        _comments.insert(0, comment);
        widget.post.commentCount += 1;
        _commentController.clear();
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceAll('Exception: ', ''))),
        );
      }
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  Future<void> _toggleLike() async {
    try {
      final updatedPost = await ApiService().toggleLike(widget.post.id);
      setState(() {
        widget.post.isLiked = updatedPost.isLiked;
        widget.post.likeCount = updatedPost.likeCount;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceAll('Exception: ', ''))),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // 返回时通知首页刷新数据，保证点赞/评论状态同步
        Navigator.pop(context, true);
        return false;
      },
      child: Scaffold(
      appBar: AppBar(
        title: const Text('树洞详情'),
        backgroundColor: Colors.teal.shade700,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  // 帖子内容
                  Card(
                    margin: const EdgeInsets.all(12),
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const CircleAvatar(
                                radius: 16,
                                backgroundColor: Color(0xFFE0F2F1),
                                child: Text('🌳', style: TextStyle(fontSize: 18)),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                widget.post.authorNickname,
                                style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: Colors.grey.shade700,
                                ),
                              ),
                              const Spacer(),
                              Text(
                                _formatTime(widget.post.createdAt),
                                style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          Text(
                            widget.post.content,
                            style: const TextStyle(fontSize: 16, height: 1.6),
                          ),
                          const SizedBox(height: 16),
                          Row(
                            children: [
                              InkWell(
                                onTap: _toggleLike,
                                borderRadius: BorderRadius.circular(20),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  child: Row(
                                    children: [
                                      Icon(
                                        widget.post.isLiked ? Icons.favorite : Icons.favorite_border,
                                        size: 20,
                                        color: widget.post.isLiked ? Colors.red : Colors.grey.shade600,
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        '${widget.post.likeCount} 赞',
                                        style: TextStyle(
                                          color: widget.post.isLiked ? Colors.red : Colors.grey.shade600,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              const SizedBox(width: 16),
                              Row(
                                children: [
                                  Icon(Icons.comment_outlined, size: 20, color: Colors.grey.shade600),
                                  const SizedBox(width: 4),
                                  Text('${widget.post.commentCount} 评论', style: TextStyle(color: Colors.grey.shade600)),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const Divider(height: 1),
                  // 评论列表
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      children: [
                        Text('全部评论', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.grey.shade800)),
                        const SizedBox(width: 8),
                        Text('(${_comments.length})', style: TextStyle(color: Colors.grey.shade600)),
                      ],
                    ),
                  ),
                  if (_isLoading)
                    const Padding(
                      padding: EdgeInsets.all(32),
                      child: Center(child: CircularProgressIndicator()),
                    )
                  else if (_comments.isEmpty)
                    Padding(
                      padding: const EdgeInsets.all(32),
                      child: Text('暂无评论，来发表第一条评论吧', style: TextStyle(color: Colors.grey.shade500)),
                    )
                  else
                    ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: _comments.length,
                      itemBuilder: (context, index) {
                        final comment = _comments[index];
                        return Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                          decoration: BoxDecoration(
                            border: Border(bottom: BorderSide(color: Colors.grey.shade200)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    comment.authorNickname,
                                    style: TextStyle(fontWeight: FontWeight.w500, color: Colors.grey.shade700, fontSize: 14),
                                  ),
                                  const Spacer(),
                                  Text(
                                    _formatTime(comment.createdAt),
                                    style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 6),
                              Text(comment.content, style: const TextStyle(height: 1.5)),
                            ],
                          ),
                        );
                      },
                    ),
                ],
              ),
            ),
          ),
          // 评论输入框
          Container(
            padding: EdgeInsets.fromLTRB(16, 8, 16, MediaQuery.of(context).padding.bottom + 8),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(color: Colors.grey.shade200, blurRadius: 4, offset: const Offset(0, -1)),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _commentController,
                    decoration: InputDecoration(
                      hintText: '写下你的评论...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide.none,
                      ),
                      filled: true,
                      fillColor: Colors.grey.shade100,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    ),
                    minLines: 1,
                    maxLines: 3,
                  ),
                ),
                const SizedBox(width: 8),
                Switch(
                  value: _isAnonymous,
                  onChanged: (value) => setState(() => _isAnonymous = value),
                  activeColor: Colors.teal.shade700,
                ),
                const Text('匿名', style: TextStyle(fontSize: 12)),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: _isSubmitting ? null : _submitComment,
                  icon: _isSubmitting
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                      : Icon(Icons.send, color: Colors.teal.shade700),
                ),
              ],
            ),
          ),
        ],
      ),
      ),
    );
  }
}
