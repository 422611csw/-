import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/post.dart';

class ApiService {
  // 后端API地址，Android模拟器用10.0.2.2访问本机，iOS模拟器用127.0.0.1
  static const String baseUrl = 'http://10.0.2.2:8000';
  String? _token;

  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('token');
  }

  Future<void> setToken(String token) async {
    _token = token;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('token', token);
  }

  Future<void> clearToken() async {
    _token = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
  }

  bool get isLoggedIn => _token != null;

  Map<String, String> get _headers => {
    'Content-Type': 'application/json',
    if (_token != null) 'Authorization': 'Bearer $_token',
  };

  // 注册
  Future<Map<String, dynamic>> register(String username, String password, {String? nickname}) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/auth/register'),
      headers: _headers,
      body: jsonEncode({
        'username': username,
        'password': password,
        if (nickname != null) 'nickname': nickname,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      await setToken(data['access_token']);
      return data;
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['detail'] ?? '注册失败');
    }
  }

  // 登录
  Future<Map<String, dynamic>> login(String username, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/auth/login'),
      headers: _headers,
      body: jsonEncode({
        'username': username,
        'password': password,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      await setToken(data['access_token']);
      return data;
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['detail'] ?? '登录失败');
    }
  }

  // 获取帖子列表
  Future<List<Post>> getPosts({int skip = 0, int limit = 20}) async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/posts/?skip=$skip&limit=$limit'),
      headers: _headers,
    );

    if (response.statusCode == 200) {
      final List<dynamic> data = jsonDecode(response.body);
      return data.map((json) => Post.fromJson(json)).toList();
    } else {
      throw Exception('获取帖子失败');
    }
  }

  // 发布帖子
  Future<Post> createPost(String content, {String mood = 'default', bool isAnonymous = true}) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/posts/'),
      headers: _headers,
      body: jsonEncode({
        'content': content,
        'mood': mood,
        'is_anonymous': isAnonymous,
      }),
    );

    if (response.statusCode == 200) {
      return Post.fromJson(jsonDecode(response.body));
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['detail'] ?? '发布失败');
    }
  }

  // 点赞/取消点赞
  Future<Post> toggleLike(int postId) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/posts/$postId/like'),
      headers: _headers,
    );

    if (response.statusCode == 200) {
      return Post.fromJson(jsonDecode(response.body));
    } else {
      throw Exception('操作失败');
    }
  }

  // 发表评论
  Future<Comment> createComment(int postId, String content, {bool isAnonymous = true}) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/posts/$postId/comments'),
      headers: _headers,
      body: jsonEncode({
        'content': content,
        'is_anonymous': isAnonymous,
      }),
    );

    if (response.statusCode == 200) {
      return Comment.fromJson(jsonDecode(response.body));
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['detail'] ?? '评论失败');
    }
  }

  // 获取帖子评论
  Future<List<Comment>> getComments(int postId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/posts/$postId/comments'),
      headers: _headers,
    );

    if (response.statusCode == 200) {
      final List<dynamic> data = jsonDecode(response.body);
      return data.map((json) => Comment.fromJson(json)).toList();
    } else {
      throw Exception('获取评论失败');
    }
  }

  // 获取当前用户信息
  Future<User> getCurrentUser() async {
    final response = await http.get(
      Uri.parse('$baseUrl/api/auth/me'),
      headers: _headers,
    );

    if (response.statusCode == 200) {
      return User.fromJson(jsonDecode(response.body));
    } else {
      throw Exception('获取用户信息失败');
    }
  }
}
