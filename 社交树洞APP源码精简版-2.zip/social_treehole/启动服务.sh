#!/bin/bash
cd "$(dirname "$0")/backend"

echo "======================================"
echo "正在启动 树洞APP 后端服务..."
echo "======================================"

echo "[1/3] 检查Python环境..."
if ! command -v python3 &> /dev/null; then
    echo "❌ 未检测到Python3，请先安装Python 3.8+"
    exit 1
fi

echo "[2/3] 安装依赖..."
pip3 install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple

echo "[3/3] 启动后端服务..."
echo ""
echo "======================================"
echo "✅ 服务启动成功！"
echo "======================================"
echo "🌐 API地址：http://localhost:8000"
echo "📚 接口文档：http://localhost:8000/docs"
echo ""
echo "📱 访问方式："
echo "1. Web版：直接打开 web/index.html 即可使用"
echo "2. Android模拟器：确保baseUrl配置为http://10.0.2.2:8000"
echo "3. iOS模拟器：baseUrl配置为http://127.0.0.1:8000"
echo "4. 真机调试：将baseUrl改为你电脑的局域网IP，手机和电脑连同一WiFi"
echo ""
echo "按 Ctrl+C 停止服务"
echo "======================================"
python3 -m uvicorn app.main:app --host 0.0.0.0 --port 8000